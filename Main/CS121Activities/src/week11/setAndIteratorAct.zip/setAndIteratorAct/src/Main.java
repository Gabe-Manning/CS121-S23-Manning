public class Main {
    public static void main(String[] args) {

        StudentSet set = new StudentSet();
        set.addStudents();
        set.displayStudents();
    }
}
