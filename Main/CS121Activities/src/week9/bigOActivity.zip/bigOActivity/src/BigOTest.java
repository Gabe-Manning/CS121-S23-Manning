public class BigOTest {
    public static void main(String[] args) {
        BigO BigO = new BigO();
        BigO.printOnce("Josh");
        BigO.printNTimes(13);
        BigO.printNSquaredTimes(2);
    }
}
