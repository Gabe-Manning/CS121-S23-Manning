package interfaces;

public interface Grade {

    double calculateGrade();
}
