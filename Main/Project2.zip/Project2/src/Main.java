//Gabe Manning
//3/21/23
public class Main {
    public static void main(String[] args) {
        //Initializes the PokemonSelection class
        PokemonSelection select = new PokemonSelection();
        //Calls the function to assign Pokemon stats and display them
        select.assignPokemon();
    }
}
